package com.example.quiz.service;

import com.example.quiz.dto.QuizCategoryListResponse;

public interface QuizService {
    public QuizCategoryListResponse getQuizzes();
}
